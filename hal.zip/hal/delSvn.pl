#!/usr/bin/perl -s


use Cwd; # module for finding the current working directory

$delete=0;

sub ScanDirectory {
    my ($workdir) = shift; 

    my($startdir) = &cwd; # keep track of where we began

    chdir($workdir) or die "Unable to enter dir $workdir:$!\n";

    opendir(DIR, ".") or die "Unable to open $workdir:$!\n";
    my @names = readdir(DIR);
    closedir(DIR);
 
    foreach my $name (@names){
        next if ($name eq "."); 
        next if ($name eq "..");

        if (-d $name){                     # is this a directory?
	    if($name eq '.svn'){
		$delete=1;
	    }
            &ScanDirectory($name);
	   
	    if($name eq '.svn'){
		$delete=0;
	    }
            next;
        }
	if($delete){ 
            print "delete FILE : " . &cwd."/".$name."\n"; # print file to delete 
	    unlink($name) or die "Unable to delete $name:$!\n";
        }

    }
    chdir($startdir) or die "Unable to change to dir $startdir:$!\n";
    if($delete){
	print "delete DIR : ". &cwd."/".$workdir."\n";  
	rmdir($workdir) or die "Unable to delete ". &cwd ."/" . $workdir . "!\n";

    }
}


&ScanDirectory(".");




#$rootDir=cwd();
#traverse ($rootDir);
#sub traverse
#{
#    my $dir = shift; #first param
#    $dir .= '/';
##unless $dir =~ m{/$};
#    opendir (DIR, $dir) || die "unable to open directory $dir: $!\n";
#    my @contents = readdir (DIR);
#    closedir (DIR);
#				 
#    for my $item (sort @contents) 
#    {
#      my $di = "$item";
#
#      next if ($item eq '.' or $item eq '..');
#      
#     
#      
#      if(-d $di)
#      {
#	 print "dir: $di\n";  
#	 traverse ($di);
#      }
#      else{
#	  print "file: $dir$di\n";
#      }
#    }
#
#}
